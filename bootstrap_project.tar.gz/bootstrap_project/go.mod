module github.com/bootstrap-median

go 1.22.2
